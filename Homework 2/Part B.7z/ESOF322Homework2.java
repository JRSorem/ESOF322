//Part B 

import java.io.IOException;
import java.util.Scanner;

public class ESOF322Homework2 {

    public static void main(String[] args) throws IOException {
        Scanner input = new Scanner(System.in);


        System.out.println("Enter data to store: ");
        String str = input.nextLine();

        System.out.println("1. Use Relational \n2. Use NoSQL \n3. Use Graph \nEnter selection: ");
        int choice = input.nextInt();
        switch (choice){
            case 1: System.out.println("Default storage algorithm is TableStore. Press 1 to use, press 2 to use DocumentStore, or press 3 to use NodeStore: ");
                    choice = input.nextInt();
                    switch(choice){
                        case 1: Relational data1 = new Relational();
                                data1.s.Store(str);
                                break;
                        case 2: Relational data2 = new Relational();
                                data2.setStoreStrategy(new documentStore());
                                data2.s.Store(str);
                                break;
                        case 3: Relational data3 = new Relational();
                                data3.setStoreStrategy((new nodeStore()));
                                data3.s.Store(str);
                                break;
                    }
                    break;
            case 2: System.out.println("Default storage algorithm is DocumentStore. Press 1 to use, press 2 to use TableStore, or press 3 to use NodeStore: ");
                choice = input.nextInt();
                switch(choice){
                    case 1: NoSQL data1 = new NoSQL();
                            data1.s.Store(str);
                            break;
                    case 2: NoSQL data2 = new NoSQL();
                            data2.setStoreStrategy(new tableStore());
                            data2.s.Store(str);
                            break;
                    case 3: NoSQL data3 = new NoSQL();
                            data3.setStoreStrategy((new nodeStore()));
                            data3.s.Store(str);
                            break;
                }
                break;
            case 3: System.out.println("Default storage algorithm is NodeStore. Press 1 to use, press 2 to use DocumentStore, or press 3 to use TableStore: ");
                choice = input.nextInt();
                switch(choice){
                    case 1: Graph data1 = new Graph();
                            data1.s.Store(str);
                            break;
                    case 2: Graph data2 = new Graph();
                            data2.setStoreStrategy(new documentStore());
                            data2.s.Store(str);
                            break;
                    case 3: Graph data3 = new Graph();
                            data3.setStoreStrategy((new tableStore()));
                            data3.s.Store(str);
                            break;
                }
                break;
            default:
        }



        //data.store(s);
    }
}
