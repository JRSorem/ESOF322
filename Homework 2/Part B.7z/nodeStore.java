import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class nodeStore implements StoreBehavior{
    public void Store(String s) throws IOException {
        FileWriter fWriter = new FileWriter("output.txt");
        PrintWriter pWriter = new PrintWriter(fWriter);
        pWriter.print(s);
        pWriter.close();
    }
}