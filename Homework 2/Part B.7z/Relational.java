import java.io.IOException;

public class Relational{
    StoreBehavior s;
    public Relational(){
        s = new tableStore();
    }
    public void setStoreStrategy(StoreBehavior b){
        s = b;
    }
}