import java.io.*;

interface StoreBehavior {
    void Store(String s)throws IOException;
}

