import java.io.*;

public class NoSQL{
    StoreBehavior s;
    public NoSQL(){
        s = new documentStore();
    }
    public void setStoreStrategy(StoreBehavior b){
        s = b;
    }
}