import java.io.*;

public class Graph{
    StoreBehavior s;
    public Graph(){
        s = new nodeStore();
    }
    public void setStoreStrategy(StoreBehavior b){
        s = b;
    }
}